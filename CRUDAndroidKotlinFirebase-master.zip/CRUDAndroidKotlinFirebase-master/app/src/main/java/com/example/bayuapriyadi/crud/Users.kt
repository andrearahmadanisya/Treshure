package com.example.bayuapriyadi.crud

class Users (var id: String, var nama : String, var status: String) {

    constructor() : this("", "","") {

    }
}